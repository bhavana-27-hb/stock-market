package org.jsp.stocks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
